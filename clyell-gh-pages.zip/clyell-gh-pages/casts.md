---
layout: page
title: "*Casts"
permalink: /casts/
---

# PodCasts

* [Clichê Cast](http://www.revistacliche.com.br)
* [Curto Circuito](http://curtocircuito.cc/)
* [DataBase Cast](http://imasters.com.br/perfil/databasecast/)
* [Dev na Estrada](http://devnaestrada.com.br/)
* [DioCast](http://www.diolinux.com.br/search/label/DioCast)
* [Direito Digital](http://josemilagre.com.br/blog/podcast/)
* [Dragões de Garagem](http://scienceblogs.com.br/dragoesdegaragem/)
* [Eureka Podcast](https://eurekapod.wordpress.com/)
* [Geek Out](https://geekout.fm/)
* [Hack’n’Cast](http://hackncast.org/)
* [I Shot the Sheriff](http://www.naopod.com.br/)
* [Piratas da Internet](https://piratasdainternet.github.io/)
* [PODEntender](http://www.podentender.com/)
* [OpenCast](http://tecnologiaaberta.com.br/category/opencast/)
* [SegInfo Cast](https://www.seginfo.com.br/seginfocast/)
* [Segurança Legal](http://www.segurancalegal.com/)
* [SobreCast](https://sobrevivencialismo.com/tag/sobrecast/)
* [Stay Safe PodCast](http://www.staysafepodcast.com.br/)
* [Talk a Byte](http://www.tabcast.com.br/)
* [Tecnologicamente Arretado](http://tecnologicamentearretado.com.br)
* [Void](http://voidpodcast.com/)
* [Zone of Front-Enders](http://zofe.com.br/)

# WebCasts

* [Security Cast](https://youtube.com/securitycast)

